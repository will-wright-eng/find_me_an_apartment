password = 'rzrnwswzwjkqccat'
myemail = 'william.cass.wright@gmail.com'
# recipients = ['william.cass.wright@gmail.com','wwright@juul.com','felicia.tissenbaum@gs.com','coheng@kenyon.edu','d.presne@gmail.com','david.resnekov@globalfounderscapital.com']
recipients = ['william.cass.wright@gmail.com']
meena = ['rezaeimeena@gmail.com']
# recipients = ['william.cass.wright@gmail.com','bryanthiraki@gmail.com', 'meena.rezaei@gmail.com']